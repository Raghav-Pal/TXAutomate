package mantisutil;

import utilities.GlobalUtil;

public interface IConstantes {
/*	static final String MANTIS_URL = "http://"+GlobalUtil.getCommonSettings().getbugToolHostName()+"/bugTool/api/soap/bugToolconnect.php";
	static final String MANTIS_USER = GlobalUtil.getCommonSettings().getbugToolUserName();
	static final String MANTIS_PWD = GlobalUtil.getCommonSettings().getbugToolPassword();
	static final String MANTIS_PROJET = GlobalUtil.getCommonSettings().getbugToolProjectName();*/
}
